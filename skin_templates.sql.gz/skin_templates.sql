-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 10. Dezember 2006 um 12:25
-- Server Version: 4.1.14
-- PHP-Version: 5.0.5
-- 
-- Datenbank: `gfx-v3`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `skin_templates`
-- 

CREATE TABLE IF NOT EXISTS `skin_templates` (
  `suid` int(10) NOT NULL auto_increment,
  `set_id` int(10) NOT NULL default '0',
  `group_name` varchar(255) collate latin1_general_ci NOT NULL default '',
  `section_content` mediumtext collate latin1_general_ci,
  `func_name` varchar(255) collate latin1_general_ci default NULL,
  `func_data` text collate latin1_general_ci,
  `updated` int(10) default NULL,
  `can_remove` tinyint(4) default '0',
  PRIMARY KEY  (`suid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1 AUTO_INCREMENT=15 ;

-- 
-- Daten für Tabelle `skin_templates`
-- 

INSERT INTO `skin_templates` (`suid`, `set_id`, `group_name`, `section_content`, `func_name`, `func_data`, `updated`, `can_remove`) VALUES (1, 1, 'skin_global', '<div id="head_strip">\r\n\r\n				<img src="images/default_skin/logo.gif" alt=""/>\r\n\r\n				<ul id="head_link_strip">\r\n\r\n					<li>\r\n\r\n						<a href="#">Forum</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Impressum</a>\r\n					</li>\r\n\r\n				</ul>\r\n\r\n			</div>', 'head_strip', NULL, NULL, 0),
(2, 1, 'skin_global', '<div id="left_navigation">\r\n\r\n				<h4>Suche</h4>\r\n\r\n				<form action="#" method="post">\r\n\r\n					<fieldset>\r\n						<input type="text" name="search_term" id="search_term"/>\r\n\r\n						<button type="submit">Suchen</button>\r\n					</fieldset>\r\n\r\n				</form>\r\n\r\n				<h3>\r\n					Fotografie\r\n					<span>So fotografiert man richtig</span>\r\n				</h3>\r\n\r\n				<ul>\r\n\r\n					<li>\r\n						<a href="#">Allgemeines</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">FAQ</a>\r\n\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Tutorials</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Galerie</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Tipps und Tricks</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Foto-Forum</a>\r\n					</li>\r\n\r\n				</ul>\r\n\r\n			</div>', 'left_navigation', NULL, NULL, 0),
(3, 1, 'skin_global', '<div id="right_block">\r\n\r\n\r\n				<ul id="top_navi">\r\n\r\n					<li>\r\n						<a href="#">Startseite</a>\r\n\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Webauthoring</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Fotografie</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Print</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Video-Editing</a>\r\n					</li>\r\n					\r\n					<li>\r\n\r\n						<a href="#">3D-Art</a>\r\n					</li>\r\n\r\n				</ul>\r\n<div id="content">\r\n\r\n					{$breadcrump}\r\n{$text}\r\n\r\n				</div>\r\n{$right_navigation}\r\n</div>', 'right_block', '$breadcrump='''', $text='''', $right_navigation=''''', NULL, 0),
(4, 1, 'skin_global', '<ul id="breadcrump">\r\n{$text}\r\n</ul>', 'breadcrump', '$text=''''', NULL, 0),
(5, 1, 'skin_global', '<li><a href="{$link}">{$text}</a></li>', 'breadcrump_bit', '$link='''', $text=''''', NULL, 0),
(6, 1, 'skin_global', '<div id="right_navigation">\r\n   {$box_1}\r\n\r\n   {$box_2}\r\n               \r\n   {$box_3}\r\n</div>', 'right_navigation', '$box_1='''', $box_2='''', $box_3=''''', NULL, 0),
(7, 1, 'artikel_tutorials', '<form method="POST" action="" >\r\n<label for="titel" >Titel: </label>\r\n<input type="text" value="{$artikel_titel}" name="artikel_titel" />\r\n<input type="submit" value="{$form_submittitel}" />\r\n</form>', 'createform', '$artikel_titel="", $form_submittitel="Absenden"', NULL, 0),
(8, 1, 'skin_global', '<form action="index.php?act=login&cmd=login" method="post">\r\n\r\n						<p>\r\n\r\n							<label for="username">Username</label>\r\n							<input type="text" name="username" id="username"/>\r\n\r\n							<label for="username">Passwort</label>\r\n\r\n							<input type="password" name="password" id="password"/>\r\n\r\n							<button type="submit">Einloggen</button>\r\n							\r\n						</p>\r\n						<p>\r\n\r\n							<a href="#">Passwort vergessen</a>\r\n							<a href="#">Registrieren</a>\r\n\r\n							\r\n						</p>\r\n					</form>', 'login_box', NULL, NULL, 0),
(9, 1, 'skin_global', '<p>\r\n						Hallo <a href="#">{$nick}</a>!<br/>\r\n						Keine neuen <a href="#">Nachrichten</a>.\r\n					</p>', 'user_box', '$nick = ''''', NULL, 0),
(10, 1, 'skin_ucp', '<div id="left_navigation">\r\n\r\n				<h4>Suche</h4>\r\n\r\n				<form action="#" method="post">\r\n\r\n					<fieldset>\r\n						<input type="text" name="search_term" id="search_term"/>\r\n\r\n						<button type="submit">Suchen</button>\r\n					</fieldset>\r\n\r\n				</form>\r\n\r\n				<h3>\r\n					UCP\r\n					<span>Dein Kontrollcenter</span>\r\n				</h3>\r\n\r\n				<ul>\r\n\r\n					<li>\r\n						<a href="#">Profil bearbeiten</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Blog verwalten</a>\r\n\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Eigene Beiträge</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Dateimanager</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Favoriten verwalten</a>\r\n					</li>\r\n\r\n					<li>\r\n						<a href="#">Buddys verwalten</a>\r\n					</li>\r\n\r\n				</ul>\r\n\r\n			</div>', 'left_navigation', NULL, NULL, 0),
(11, 1, 'skin_global', '<div id="page_intro">\r\n\r\n						<h1>{$header}</h1>\r\n						<p>{$text}</p>\r\n\r\n					</div>', 'page_intro', '$header = '''', $text = ''''', NULL, 0),
(12, 1, 'skin_global', '<li>\r\n<a href="{$link}">{$text}</a>\r\n</li>', 'link_list_bit', '$link = '''', $text = ''''', NULL, 0),
(13, 1, 'skin_global', '<ul class="simple_listing">\r\n{$items}\r\n</ul>', 'simple_listing', '$items = ''''', NULL, 0),
(14, 1, 'skin_ucp', '<h2>Notizen</h2>\r\n<form id="note-pad" action="ucp/save_note" method="post">\r\n\r\n<p>\r\n<textarea cols="50" rows="5" name="notes">{$notes}</textarea>\r\n<button type="submit" accesskey="s">Speichern</button>\r\n</p>\r\n\r\n</form>\r\n<h2>Neue Kommentare auf</h2>\r\n\r\n<ul class="simple_listing">\r\n{$items_1}\r\n</ul>\r\n\r\n<h2>Zuletzt betrachtete Dinge</h2>\r\n\r\n<ul class="simple_listing">\r\n{$items_2}\r\n</ul>', 'ucp_home', '$notes = '''', $items_1 = '''', $items_2 = ''''', NULL, 0);
